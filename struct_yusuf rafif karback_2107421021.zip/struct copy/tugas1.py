from collections import namedtuple


Student = namedtuple('student', ['nama', 'umur', 'kelas'])

nama = input('masukan nama: ')
umur = input('masukan umur: ')
kelas = input('masukan kelas: ')

student1 = Student(nama, umur, kelas)

print(type(student1))
print(student1.nama)
print(student1.umur)
print(student1.kelas)
