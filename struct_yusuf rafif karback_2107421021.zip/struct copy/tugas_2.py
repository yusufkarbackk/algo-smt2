from collections import namedtuple

Mobil = namedtuple('Mobil', ['merk_mobil', 'tipe_mobil', 'harga'])

merk_mobil = input('masukan merk mobil: ')
tipe_mobil = input('masukan tipe mobil: ')
harga = input('masukan harga: ')
mobil1 = Mobil(merk_mobil, tipe_mobil, harga)

merk_mobil = input('masukan merk mobil: ')
tipe_mobil = input('masukan tipe mobil: ')
harga = input('masukan harga: ')
mobil2 = Mobil(merk_mobil, tipe_mobil, harga)

merk_mobil = input('masukan merk mobil: ')
tipe_mobil = input('masukan tipe mobil: ')
harga = input('masukan harga: ')
mobil3 = Mobil(merk_mobil, tipe_mobil, harga)

print(type(mobil1))
print(mobil1.merk_mobil, ",", mobil1.tipe_mobil, ",", mobil1.harga)
print()

print(type(mobil2))
print(mobil2.merk_mobil, ",", mobil2.tipe_mobil, ",", mobil2.harga)

print()
print(type(mobil3))
print(mobil3.merk_mobil, ",", mobil3.tipe_mobil, ",", mobil3.harga)



# ===========================================

Motor = namedtuple('Motor', ['merk_motor', 'tipe_motor', 'harga'])

merk_motor = input('masukan merk motor: ')
tipe_motor = input('masukan tipe motor: ')
harga = input('masukan harga: ')
motor1 = Motor(merk_motor, tipe_motor, harga)

merk_motor = input('masukan merk motor: ')
tipe_motor = input('masukan tipe motor: ')
harga = input('masukan harga: ')
motor2 = Motor(merk_motor, tipe_motor, harga)

merk_motor = input('masukan merk motor: ')
tipe_motor = input('masukan tipe motor: ')
harga = input('masukan harga: ')
motor3 = Motor(merk_motor, tipe_motor, harga)

print(type(motor1))
print(motor1.merk_motor, ",", motor1.tipe_motor, ",", motor1.harga)

print(type(motor2))
print(motor2.merk_motor, ",", motor2.tipe_motor, ",", motor2.harga)

print(type(motor3))
print(motor3.merk_motor, ",", motor3.tipe_motor, ",", motor3.harga)


# =================================

Karyawan = namedtuple('Karyawan', ['nama', 'jabatan', 'gaji'])

nama = input('masukan nama: ')
jabatan = input('masukan jabatan: ')
gaji = input('masukan gaji: ')
karyawan1 = Karyawan(nama, jabatan, gaji)

nama = input('masukan nama: ')
jabatan = input('masukan jabatan: ')
gaji = input('masukan gaji: ')
karyawan2 = Karyawan(nama, jabatan, gaji)

nama = input('masukan nama: ')
jabatan = input('masukan jabatan: ')
gaji = input('masukan gaji: ')
karyawan3 = Karyawan(nama, jabatan, gaji)

print(type(karyawan1))
print(karyawan1.nama, ",", karyawan1.jabatan, ",", karyawan1.gaji)

print(type(karyawan2))
print(karyawan2.nama, ",", karyawan2.jabatan, ",", karyawan2.gaji)

print(type(karyawan3))
print(karyawan3.nama, ",", karyawan3.jabatan, ",", karyawan3.gaji)
