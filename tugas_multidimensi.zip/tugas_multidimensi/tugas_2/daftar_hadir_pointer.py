import ctypes


def tampilkan_daftar(daftar):
    daftar_value = ctypes.cast(daftar, ctypes.py_object).value
    for i in range(len(daftar_value)):
        for j in range(len(daftar_value[i])):
            print(daftar_value[i][j], end=" | ")
        print()
        print("=" * 40)


def tambah_daftar(daftar):
    daftar_value = ctypes.cast(daftar, ctypes.py_object).value

    nomor = int(input('no: '))
    hari = input('hari: ')
    tanggal = input('tanggal: ')
    tujuan = input('maksud tujuan: ')
    ttd = input('tanda tangan: ')

    data = [nomor, hari, tanggal, tujuan, ttd]
    daftar_value.append(data)


def daftar_hadir():
    daftar = [
        ['No', 'Hari', 'tanggal', 'tujuan', 'ttd']
    ]

    address_daftar = id(daftar)

    while(True):
        print('selamat datang di daftar hadir')
        print('1. tambah daftar')
        print('2. keluar')
        user = input('masukan pilihan: ')

        if(user == '1'):
            tambah_daftar(address_daftar)
            tampilkan_daftar(address_daftar)

        else:
            break


daftar_hadir()
