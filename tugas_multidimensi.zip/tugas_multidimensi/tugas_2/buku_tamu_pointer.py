import ctypes

def tampilkan_buku(buku):
    buku_value = ctypes.cast(buku, ctypes.py_object).value #mengambil nilai dari alamat memory
    for i in range(len(buku_value)):
        for j in range(len(buku_value[i])):
            print(buku_value[i][j], end=" | ")
        print()
        print("=" * 40)


def tambah_tamu(daftar):
    buku_value = ctypes.cast(daftar, ctypes.py_object).value #mengambil nilai dari alamat memory

    nim = int(input('nim: '))
    nama = input('nama: ')
    tanggal = input('tanggal: ')
    ttd = input('tanda tangan: ')

    data = [nim, nama, tanggal, ttd]
    buku_value.append(data)


def buku_tamu():
    buku_tamu = [
        ['nim', 'nama', 'tanggal kunjungan', 'ttd']
    ]

    address_buku = id(buku_tamu)

    while(True):
        print('selamat datang di buku tamu')
        print('1. tambah tamu')
        print('2. keluar')
        user = input('masukan pilihan: ')

        if(user == '1'):
            tambah_tamu(address_buku)
            tampilkan_buku(address_buku)

        else:
            break


buku_tamu()
