def tampilkan_buku(buku):
    for i in range(len(buku)):
        for j in range(len(buku[i])):
            print(buku[i][j], end=" | ")
        print()
        print("=" * 40)


def tambah_tamu(buku):
    nim = int(input('masukan nim: '))
    nama = input('masukan nama: ')
    tanggal = input('masukan tanggal: ')
    ttd = input('masukan tanda tangan: ')

    data = [nim, nama, tanggal, ttd]
    buku.append(data)


def buku_tamu():
    buku = [
        ['nim', 'nama', 'tanggal kunjungan', 'ttd']
    ]

    while(True):
        print('selamat datang di buku tamu')
        print('1. tambah tamu')
        print('2. keluar')
        user = input('masukan pilihan: ')

        if(user == '1'):
            tambah_tamu(buku)
            tampilkan_buku(buku)
            print(buku)

        else:
            break


buku_tamu()
