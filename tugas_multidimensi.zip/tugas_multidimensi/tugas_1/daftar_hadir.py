def tampilkan_daftar(daftar):
    for i in range(len(daftar)):
        for j in range(len(daftar[i])):
            print(daftar[i][j], end=" | ")
        print()
        print("=" * 40)


def tambah_daftar(daftar):
    nomor = int(input('no: '))
    hari = input('hari: ')
    tanggal = input('tanggal: ')
    tujuan = input('maksud tujuan: ')
    ttd = input('tanda tangan: ')

    data = [nomor, hari, tanggal, tujuan, ttd]
    daftar.append(data)


def daftar_hadir():
    daftar = [
        ['No', 'Hari', 'tanggal', 'tujuan', 'ttd']
    ]

    while(True):
        print('selamat datang di daftar hadir')
        print('1. tambah daftar')
        print('2. keluar')
        user = input('masukan pilihan: ')

        if(user == '1'):
            tambah_daftar(daftar)
            tampilkan_daftar(daftar)

        else:
            break


daftar_hadir()
